package bugsquashers.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.ShopKeeperDao;
import bugsquashers.entity.ShopKeeper;
import bugsquashers.repositories.ShopKeeperRepo;

@Service
public class ShopKeeperService implements ShopKeeperRepo {
	@Autowired
	private ShopKeeperDao sk;
     @Override
     
	public List<ShopKeeper> getShopKeeper() {
		
		return sk.findAll();
	}

	@Override
	public ShopKeeper getShopKeeper(int sid) 
	{   return sk.findById(sid).get();
		
	}

	@Override
	public ShopKeeper addShopKeeper(ShopKeeper k) {
	return sk.save(k);
	
	}

	@Override
	public ShopKeeper updateShopKeeper(ShopKeeper k) {
	return sk.save(k);

	}

	@Override
	public void deleteShopKeeper( int sid) {
		ShopKeeper k=sk.getById(sid);
		sk.delete(k);
	}
	
	

}

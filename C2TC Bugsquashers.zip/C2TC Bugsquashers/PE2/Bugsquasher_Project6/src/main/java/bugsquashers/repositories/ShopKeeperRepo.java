package bugsquashers.repositories;
import java.util.List;

import bugsquashers.entity.ShopKeeper;

public interface ShopKeeperRepo {
	  public  List<ShopKeeper> getShopKeeper();
	    public ShopKeeper getShopKeeper(int sid);
	   public ShopKeeper addShopKeeper(ShopKeeper k);
	   public ShopKeeper updateShopKeeper(ShopKeeper k);
	   public  void deleteShopKeeper(int sid);
	   
}

package bugsquashers.entity;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ShopKeeper {
	@Id
    private int sid;
    private String name;  
    private String address;
    private String shop;
    public ShopKeeper()
    {
    }
    
	public ShopKeeper(int sid, String name, String address, String shop) {
		super();
		this.sid = sid;
		this.name = name;
		this.address = address;
		this.shop = shop;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	@Override
	public String toString() {
		return "ShopKeeper [sid=" + sid + ", name=" + name + ", address=" + address + ", shop=" + shop + "]";
	}
    
}

package bugsquashers.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import bugsquashers.entity.Shop;

import bugsquashers.repositories.ShopRepo;


import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;
@RestController
public class ShopController {
	@Autowired
	ShopRepo shp;
	@GetMapping("/getShop")
		
		public List<Shop> getShop()
		{
			return shp.getShop();

		}
	   @GetMapping("/getShop/{sid}")
	     public Shop getShop(@PathVariable String sid)
	     {
	    	 return shp.getShop(Integer.parseInt(sid));
	     }
	   @PostMapping("/addShop")
	    public Shop addShop(@RequestBody Shop s)
	    {
	    	return shp.addShop(s);
	    }
	   @PutMapping("/updateShop")
	   public Shop updateShop(@RequestBody Shop s)
	   {
	   	return shp.addShop(s);
	   }
	   @DeleteMapping("/deleteShop/{sid}")
	   public void delete(@PathVariable int sid)
	   {
		  shp.deleteShop(sid);

	   }
	}
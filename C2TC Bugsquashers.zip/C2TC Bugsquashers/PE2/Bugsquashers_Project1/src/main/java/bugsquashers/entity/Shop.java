package bugsquashers.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Shop {
	@Id
    private int sid;
    private String name;  
	private String owner;
    private String leasestatus;
    public Shop()
    {
    	
    }
	public Shop(int sid, String name, String owner, String leasestatus) {
		super();
		this.sid = sid;
		this.name = name;
		this.owner = owner;
		this.leasestatus = leasestatus;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getLeasestatus() {
		return leasestatus;
	}
	public void setLeasestatus(String leasestatus) {
		this.leasestatus = leasestatus;
	}
	@Override
	public String toString() {
		return "Shop [sid=" + sid + ", name=" + name + ", owner=" + owner + ", leasestatus=" + leasestatus + "]";
	}
	
    
 

}

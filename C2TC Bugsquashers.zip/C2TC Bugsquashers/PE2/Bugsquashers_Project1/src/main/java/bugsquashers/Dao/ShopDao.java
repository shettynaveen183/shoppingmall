package bugsquashers.Dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import bugsquashers.entity.Shop;


@Component
public interface ShopDao extends JpaRepository<Shop, Integer>{

}

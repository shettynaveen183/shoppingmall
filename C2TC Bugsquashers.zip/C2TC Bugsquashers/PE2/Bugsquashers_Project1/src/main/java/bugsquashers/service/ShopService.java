package bugsquashers.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.ShopDao;

import bugsquashers.entity.Shop;

import bugsquashers.repositories.ShopRepo;
@Service
public class ShopService implements ShopRepo{
	@Autowired
	private ShopDao sp;
     @Override
     
	public List<Shop> getShop() {
		
		return sp.findAll();
	}

	@Override
	public Shop getShop(int sid) 
	{   return sp.getById(sid);
		
	}

	@Override
	public Shop addShop(Shop s) {
	return sp.save(s);
	
	}

	@Override
	public Shop updateShop(Shop s) {
	return sp.save(s);

	}

	@Override
	public void deleteShop( int sid) {
		Shop s=sp.getById(sid);
		sp.delete(s);
	}
	
}

package bugsquashers.repositories;
import bugsquashers.entity.Shop;
import java.util.List;

public interface ShopRepo {
	 public  List<Shop> getShop();
	    public Shop getShop(int sid);
	   public Shop addShop(Shop s);
	   public Shop updateShop(Shop s);
	   public  void deleteShop(int sid);

}

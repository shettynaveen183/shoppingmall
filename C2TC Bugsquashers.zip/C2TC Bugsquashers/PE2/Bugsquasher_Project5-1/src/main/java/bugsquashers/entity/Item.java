package bugsquashers.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Item {
	@Id
    private int iid;
    private String name;  
	private char manufacturing;
    private char expiry;
    private char price;
    public Item()
    {
    	
    }
	public Item(int iid, String name, char manufacturing, char expiry, char price) {
		super();
		this.iid = iid;
		this.name = name;
		this.manufacturing = manufacturing;
		this.expiry = expiry;
		this.price = price;
	}
	public int getIid() {
		return iid;
	}
	public void setIid(int iid) {
		this.iid = iid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public char getManufacturing() {
		return manufacturing;
	}
	public void setManufacturing(char manufacturing) {
		this.manufacturing = manufacturing;
	}
	public char getExpiry() {
		return expiry;
	}
	public void setExpiry(char expiry) {
		this.expiry = expiry;
	}
	public char getPrice() {
		return price;
	}
	public void setPrice(char price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Item [iid=" + iid + ", name=" + name + ", manufacturing=" + manufacturing + ", expiry=" + expiry
				+ ", price=" + price + "]";
	}
  
}

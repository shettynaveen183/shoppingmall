package bugsquashers.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.ItemDao;
import bugsquashers.entity.Item;
import bugsquashers.repositories.ItemRepo;


@Service
public class ItemService implements ItemRepo {
	@Autowired
	private ItemDao it;
     @Override
     
	public List<Item> getItem() {
		
		return it.findAll();
	}

	@Override
	public Item getItem(int iid) 
	{   return it.getById(iid);
		
	}

	@Override
	public Item addItem(Item i) {
	return it.save(i);
	
	}

	@Override
	public Item updateItem(Item i) {
	return it.save(i);

	}

	@Override
	public void deleteItem( int iid) {
		Item i=it.getById(iid);
		it.delete(i);
	}
	
	

}

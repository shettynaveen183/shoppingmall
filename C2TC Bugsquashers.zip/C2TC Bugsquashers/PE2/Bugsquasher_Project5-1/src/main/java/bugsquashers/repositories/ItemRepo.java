package bugsquashers.repositories;
import java.util.List;

import bugsquashers.entity.Item;

public interface ItemRepo {
	public  List<Item> getItem();
    public Item getItem(int iid);
   public Item addItem(Item i);
   public Item updateItem(Item i);
   public  void deleteItem(int iid);
   

}

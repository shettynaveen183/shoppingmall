package bugsquashers.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import bugsquashers.entity.Item;
import bugsquashers.repositories.ItemRepo;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;



@RestController
public class ItemController {
	@Autowired
	ItemRepo ite;
	@GetMapping("/getItem")
		
		public List<Item> getItem()
		{
			return ite.getItem();

		}
	   @GetMapping("/getItem/{iid}")
	     public Item getItem(@PathVariable String iid)
	     {
	    	 return ite.getItem(Integer.parseInt(iid));
	     }
	   @PostMapping("/addItem")
	    public Item addItem(@RequestBody Item i)
	    {
	    	return ite.addItem(i);
	    }
	   @PutMapping("/updateItem")
	   public Item updateItem(@RequestBody Item i)
	   {
	   	return ite.addItem(i);
	   }
	   @DeleteMapping("/deleteItem/{iid}")
	   public void delete(@PathVariable int iid)
	   {
		  ite.deleteItem(iid);

	   }

}

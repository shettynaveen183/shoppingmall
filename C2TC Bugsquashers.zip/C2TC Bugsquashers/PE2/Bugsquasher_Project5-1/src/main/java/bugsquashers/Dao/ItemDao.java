package bugsquashers.Dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import bugsquashers.entity.Item;
@Component
public interface ItemDao extends JpaRepository<Item, Integer>{
	

}

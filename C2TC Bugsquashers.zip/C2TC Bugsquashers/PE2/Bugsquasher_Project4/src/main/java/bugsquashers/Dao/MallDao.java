package bugsquashers.Dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import bugsquashers.entity.Mall;




@Component
public interface MallDao extends JpaRepository<Mall, Integer>{

}

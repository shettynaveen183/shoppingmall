package bugsquashers.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.MallDao;
import bugsquashers.entity.Mall;
import bugsquashers.repositories.MallRepo;
@Service
public class MallService implements MallRepo {
	@Autowired
	private MallDao ma;
     @Override
     
	public List<Mall> getMall() {
		
		return ma.findAll();
	}

	@Override
	public Mall getMall(int mid) 
	{  
		return ma.getById(mid);
		
	}

	@Override
	public Mall addMall(Mall m) {
	return ma.save(m);
	
	}

	@Override
	public Mall updateMall(Mall m) {
	return ma.save(m);

	}

	@Override
	public void deleteMall( int mid) {
		Mall m=ma.getById(mid);
		ma.delete(m);
	}
	

}

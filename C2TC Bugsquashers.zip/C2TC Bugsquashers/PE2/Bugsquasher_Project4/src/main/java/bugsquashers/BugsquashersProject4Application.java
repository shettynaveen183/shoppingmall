package bugsquashers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugsquashersProject4Application {

	public static void main(String[] args) {
		SpringApplication.run(BugsquashersProject4Application.class, args);
	}

}

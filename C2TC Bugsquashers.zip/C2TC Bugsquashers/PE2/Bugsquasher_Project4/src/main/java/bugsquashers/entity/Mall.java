package bugsquashers.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Mall {
	@Id
    private int mid;
    private String m_name;  
	private String m_admin;
     private String shops;
     public Mall()
     {
    	 
     }
	public Mall(int mid, String m_name, String m_admin, String shops) {
		super();
		this.mid = mid;
		this.m_name = m_name;
		this.m_admin = m_admin;
		this.shops = shops;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getM_admin() {
		return m_admin;
	}
	public void setM_admin(String m_admin) {
		this.m_admin = m_admin;
	}
	public String getShops() {
		return shops;
	}
	public void setShops(String shops) {
		this.shops = shops;
	}
	@Override
	public String toString() {
		return "Mall [mid=" + mid + ", m_name=" + m_name + ", m_admin=" + m_admin + ", shops=" + shops + "]";
	}
     
    
}

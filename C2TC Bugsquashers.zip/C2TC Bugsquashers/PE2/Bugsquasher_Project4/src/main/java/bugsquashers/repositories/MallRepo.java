package bugsquashers.repositories;

import java.util.List;

import bugsquashers.entity.Mall;

public interface MallRepo {
	public  List<Mall> getMall();
    public Mall getMall(int mid);
   public Mall addMall(Mall m);
   public Mall updateMall(Mall m);
   public  void deleteMall(int mid);
   

}

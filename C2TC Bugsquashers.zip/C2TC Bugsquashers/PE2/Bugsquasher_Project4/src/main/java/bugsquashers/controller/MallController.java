package bugsquashers.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import bugsquashers.entity.Mall;
import bugsquashers.repositories.MallRepo;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;



@RestController
public class MallController {
	@Autowired
	MallRepo mal;
	@GetMapping("/getMall")
		
		public List<Mall> getMall()
		{
			return mal.getMall();

		}
	   @GetMapping("/getMall/{mid}")
	     public Mall getMall(@PathVariable String mid)
	     {
	    	 return mal.getMall(Integer.parseInt(mid));
	     }
	   @PostMapping("/addMall")
	    public Mall addMall(@RequestBody Mall m)
	    {
	    	return mal.addMall(m);
	    }
	   @PutMapping("/updateMall")
	   public Mall updateMall(@RequestBody Mall m)
	   {
	   	return mal.addMall(m);
	   }
	   @DeleteMapping("/deleteMall/{mid}")
	   public void delete(@PathVariable int mid)
	   {
		  mal.deleteMall(mid);

	   }
}

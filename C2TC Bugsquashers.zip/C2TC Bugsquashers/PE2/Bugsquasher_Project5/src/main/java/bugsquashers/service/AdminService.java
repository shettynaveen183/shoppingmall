package bugsquashers.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.AdminDao;
import bugsquashers.entity.Admin;
import bugsquashers.repositories.AdminRepo;


@Service
public class AdminService implements AdminRepo{
	@Autowired
	private AdminDao ad;
     @Override
     
	public List<Admin> getAdmin() {
		
		return ad.findAll();
	}

	@Override
	public Admin getAdmin(int aid) 
	{   return ad.getById(aid);
		
	}

	@Override
	public Admin addAdmin(Admin a) {
	return ad.save(a);
	
	}

	@Override
	public Admin updateAdmin(Admin a) {
	return ad.save(a);

	}

	@Override
	public void deleteAdmin( int aid) {
		Admin a=ad.getById(aid);
		ad.delete(a);
	}
	
	

}

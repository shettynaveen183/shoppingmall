package bugsquashers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugsquashersProject5Application {

	public static void main(String[] args) {
		SpringApplication.run(BugsquashersProject5Application.class, args);
	}

}

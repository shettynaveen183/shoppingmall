package bugsquashers.repositories;
import java.util.List;

import bugsquashers.entity.Admin;


public interface AdminRepo {
	public  List<Admin> getAdmin();
    public Admin getAdmin(int eid);
   public Admin addAdmin(Admin e);
   public Admin updateAdmin(Admin e);
   public  void deleteAdmin(int eid);
   

}

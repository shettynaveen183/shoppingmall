package bugsquashers.Dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import bugsquashers.entity.Admin;
@Component
public interface AdminDao extends JpaRepository<Admin, Integer> {

}

package bugsquashers.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.UserDao;
import bugsquashers.entity.User;
import bugsquashers.repositories.UserRepo;


@Service
public class UserService implements UserRepo {
	@Autowired
	private UserDao us;
     @Override
     
	public List<User> getUser() {
		
		return us.findAll();
	}

	@Override
	public User getUser(int uid) 
	{  
		return us.getById(uid);
		
	}

	@Override
	public User addUser(User u) {
	return us.save(u);
	
	}

	@Override
	public User updateUser(User u) {
	return us.save(u);

	}

	@Override
	public void deleteUser( int uid) {
		User u=us.getById(uid);
		us.delete(u);
	}
	
	

}

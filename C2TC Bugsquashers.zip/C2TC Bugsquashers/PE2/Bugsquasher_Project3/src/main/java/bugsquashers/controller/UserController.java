package bugsquashers.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import bugsquashers.entity.User;
import bugsquashers.repositories.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;



@RestController
public class UserController {
	@Autowired
	UserRepo usr;
	@GetMapping("/getUser")
		
		public List<User> getUser()
		{
			return usr.getUser();

		}
	   @GetMapping("/getUser/{uid}")
	     public User getUser(@PathVariable String uid)
	     {
	    	 return usr.getUser(Integer.parseInt(uid));
	     }
	   @PostMapping("/addUser")
	    public User addEmployee(@RequestBody User u)
	    {
	    	return usr.addUser(u);
	    }
	   @PutMapping("/updateUser")
	   public User updateUser(@RequestBody User u)
	   {
	   	return usr.addUser(u);
	   }
	   @DeleteMapping("/deleteUser/{uid}")
	   public void delete(@PathVariable int uid)
	   {
		  usr.deleteUser(uid);

	   }
}

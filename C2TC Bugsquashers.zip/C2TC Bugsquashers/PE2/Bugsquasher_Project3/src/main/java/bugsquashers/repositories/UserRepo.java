package bugsquashers.repositories;
import java.util.List;

import bugsquashers.entity.User;





public interface UserRepo {
   public  List<User> getUser();
    public User getUser(int uid);
   public User addUser(User u);
   public User updateUser(User u);
   public  void deleteUser(int uid);
   
	
}

package bugsquashers.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.EmployeeDao;
import bugsquashers.entity.Employee;
import bugsquashers.repositories.EmployeeRepo;


@Service
public class EmployeeService implements EmployeeRepo{
	@Autowired
	private EmployeeDao ed;
     @Override
     
	public List<Employee> getEmployee() {
		
		return ed.findAll();
	}

	@Override
	public Employee getEmployee(int eid) 
	{   return ed.getById(eid);
		
	}

	@Override
	public Employee addEmployee(Employee e) {
	return ed.save(e);
	
	}

	@Override
	public Employee updateEmployee(Employee e) {
	return ed.save(e);

	}

	@Override
	public void deleteEmployee( int eid) {
		Employee e=ed.getById(eid);
		ed.delete(e);
	}
	
	

}

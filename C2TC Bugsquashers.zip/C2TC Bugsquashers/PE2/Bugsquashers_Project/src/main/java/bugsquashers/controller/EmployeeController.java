package bugsquashers.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import bugsquashers.entity.Employee;
import bugsquashers.repositories.EmployeeRepo;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;



@RestController
public class EmployeeController {
	
@Autowired
EmployeeRepo emp;
@GetMapping("/getEmployee")
	
	public List<Employee> getEmployee()
	{
		return emp.getEmployee();

	}
   @GetMapping("/getEmployee/{eid}")
     public Employee getEmployee(@PathVariable String eid)
     {
    	 return emp.getEmployee(Integer.parseInt(eid));
     }
   @PostMapping("/addEmployee")
    public Employee addEmployee(@RequestBody Employee e)
    {
    	return emp.addEmployee(e);
    }
   @PutMapping("/updateEmployee")
   public Employee updateEmployee(@RequestBody Employee e)
   {
   	return emp.addEmployee(e);
   }
   @DeleteMapping("/deleteEmployee/{eid}")
   public void delete(@PathVariable int eid)
   {
	  emp.deleteEmployee(eid);

   }
}

package bugsquashers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugsquashersProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BugsquashersProjectApplication.class, args);
	}

}

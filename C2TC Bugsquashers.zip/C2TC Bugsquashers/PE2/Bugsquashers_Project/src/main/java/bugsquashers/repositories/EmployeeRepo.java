package bugsquashers.repositories;
import java.util.List;

import bugsquashers.entity.Employee;





public interface EmployeeRepo {
   public  List<Employee> getEmployee();
    public Employee getEmployee(int eid);
   public Employee addEmployee(Employee e);
   public Employee updateEmployee(Employee e);
   public  void deleteEmployee(int eid);
   
	
}

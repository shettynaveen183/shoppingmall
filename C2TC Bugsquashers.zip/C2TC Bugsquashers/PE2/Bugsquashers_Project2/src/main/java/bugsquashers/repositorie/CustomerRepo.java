package bugsquashers.repositorie;
import java.util.List;

import bugsquashers.entity.Customer;


public interface CustomerRepo {
	 public  List<Customer> getCustomer();
	    public Customer getCustomer(int cid);
	   public Customer addCustomer(Customer c);
	   public Customer updateCustomer(Customer c);
	   public  void deleteCustomer(int eid);
	   

}

package bugsquashers.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bugsquashers.Dao.CustomerDao;
import bugsquashers.entity.Customer;
import bugsquashers.repositorie.CustomerRepo;


@Service
public class CustomerService implements CustomerRepo{
	@Autowired
	private CustomerDao cu;
     @Override
     
	public List<Customer> getCustomer() {
		
		return cu.findAll();
	}

	@Override
	public Customer getCustomer(int cid) 
	{   return cu.getById(cid);
		
	}

	@Override
	public Customer addCustomer(Customer c) {
	return cu.save(c);
	
	}

	@Override
	public Customer updateCustomer(Customer c) {
	return cu.save(c);

	}

	@Override
	public void deleteCustomer( int cid) {
		Customer c=cu.getById(cid);
		cu.delete(c);
	}

}

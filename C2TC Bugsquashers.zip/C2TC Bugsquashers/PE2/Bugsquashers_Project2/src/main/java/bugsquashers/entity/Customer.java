package bugsquashers.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity

public class Customer {
	@Id
    private int cid;
    private String name;  
	private String orders;
    private String phone_no ;
    private String email;
    public Customer()
    {
    	
    }
	public Customer(int cid, String name, String orders, String phone_no, String email) {
		super();
		this.cid = cid;
		this.name = name;
		this.orders = orders;
		this.phone_no = phone_no;
		this.email = email;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrders() {
		return orders;
	}
	public void setOrders(String orders) {
		this.orders = orders;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", name=" + name + ", orders=" + orders + ", phone_no=" + phone_no + ", email="
				+ email + "]";
	}

}

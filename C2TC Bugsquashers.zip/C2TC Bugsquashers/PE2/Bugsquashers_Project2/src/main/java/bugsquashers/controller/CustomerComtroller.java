package bugsquashers.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import bugsquashers.entity.Customer;
import bugsquashers.repositorie.CustomerRepo;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;
@RestController

public class CustomerComtroller {
	@Autowired
	CustomerRepo cus;
	@GetMapping("/getCustomer")
		
		public List<Customer> getCustomer()
		{
			return cus.getCustomer();

		}
	   @GetMapping("/getCustomer/{cid}")
	     public Customer getCustomer(@PathVariable String cid)
	     {
	    	 return cus.getCustomer(Integer.parseInt(cid));
	     }
	   @PostMapping("/addCustomer")
	    public Customer addCustomer(@RequestBody Customer c)
	    {
	    	return cus.addCustomer(c);
	    }
	   @PutMapping("/updateCustomer")
	   public Customer updateCustomer(@RequestBody Customer c)
	   {
	   	return cus.addCustomer(c);
	   }
	   @DeleteMapping("/deleteCustomer/{cid}")
	   public void delete(@PathVariable int cid)
	   {
		  cus.deleteCustomer(cid);

	   }
}
